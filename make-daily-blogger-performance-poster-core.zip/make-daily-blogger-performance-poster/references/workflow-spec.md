# 今日草原博主排名：共同数据规格与可选混合合成

## 当天数据源

- 指定账号：股市小新，抖音号 `70750098285`。
- 主页：`https://www.douyin.com/user/MS4wLjABAAAAfVv4yOp0cwz7FLWSn5Kpp4GjDbKg4dzNUWRDOAViFhPgXbKLGdsixB5W0gAsrloS`。
- 只使用 Asia/Shanghai 当天实际发布的最新成绩单。排除置顶假最新，记录最终作品 URL、发布时间、原图或清晰截图路径。
- 用户直接提供当天清晰成绩单时仍须核对图上日期和每行归属。来源未发布、糊图、日期不符或任何字段有疑义时停止正式海报，绝不用昨日数据填补。
- 自动运行前先判真实中国 A 股交易日；非交易日安静跳过。

## 固定九人与固定照片

本任务的用户指定范围为以下九人；只展示其中**当天有可核实收益率**者。旧昵称“大胡子闲闲”在成品中统一显示“大胡子”。

| 显示名 | slug | 优先固定头像 | 备用照片 |
|---|---|---|---|
| 大胡子 | dahuzi | `头像/原服装透明抠图/dahuzi.png` | `头像/原服装海报头像/dahuzi.png` |
| 大曾子 | dazengzi | `头像/原服装透明抠图/dazengzi.png` | `头像/原服装海报头像/dazengzi.png` |
| 老徐 | laoxu | `头像/原服装透明抠图/laoxu.png` | `头像/原服装海报头像/laoxu.png` |
| 接盘哥 | jiepange | `头像/原服装透明抠图/jiepange.png` | `头像/原服装海报头像/jiepange.png` |
| 小张吃饭用缸 | xiaozhang | `头像/原服装透明抠图/xiaozhang.png` | `头像/原服装海报头像/xiaozhang.png` |
| 孙大鑫 | sundaxin | `头像/原服装透明抠图/sundaxin.png` | `头像/原服装海报头像/sundaxin.png` |
| 王小雨 | wangxiaoyu | `头像/原服装透明抠图/wangxiaoyu.png` | `头像/原服装海报头像/wangxiaoyu.png` |
| 小热巴 | xiaoreba | `头像/原服装透明抠图/xiaoreba.png` | `头像/原服装海报头像/xiaoreba.png` |
| 全能的野人 | yeren | `头像/yeren.png` | `skills/assets/portraits-original-outfit/yeren.png` |

`头像/` 的绝对根目录为 `/Users/jinru/Desktop/博主今日战绩/头像`。原八人若桌面文件缺失，再用本技能 `assets/portraits-original-outfit/<slug>.png` 兜底；同名都缺失则报告，不借用其他人照片。全能的野人图片可能带原背景，读取实际 alpha；若不透明则用干净照片窗口，不做粗糙抠图。所有照片仅等比缩放/必要裁切/边缘阴影，不改变脸型、五官、眼镜、发型、皮肤、表情和服装。

`assets/identity-sheet-a.png` 与 `assets/identity-sheet-b.png` 是一次性 Image2 生成的无字身份对照图，可供人工快速核对，但不能替代上述单人原图。默认整图 Image2.5 模式以当天上榜者的**每张原头像**为身份来源：参考图名额足够时逐张提交；受原生工具参考图数量上限限制时，可把这些原头像无损排入 2–3 张带姓名标签的临时身份参考板。参考板只压缩输入数量，不替代单人原图验收，也不能作为贴图素材。模型重绘后不保证身份不变，明显改脸、改衣即未通过。仅在用户选用混合合成路线时，才从上述单人原图直接取像素，不从参考表或旧海报裁人。

## 一次核验清单

每人绑定同一条记录：`name, slug, total, today, pct, quote, source_evidence, present`。核对九人“出席/缺席”状态；只渲染今天有可核实收益率者。总数、今日盈亏未披露但收益率已披露者可写 `—`；不可用旧数据补齐。按收益率从高到低排列，但画面不显示排名编号；默认主视觉为收益率最高者，用户当次指定主角则覆盖。

- 总数：`31.7w`，小写 `w`，不写“万”或大写 `W`。
- 今日盈亏：`+9,024`、`-28,840`，正负号与英文逗号完整。
- 收益率：`+2.92%`、`-1.14%`，精度与来源一致。零值按来源实际精度显示。
- 未披露：`—`。
- A 股颜色：正数红、负数绿、中性灰/白。
- 每位上榜者有可核实当日原话时均在本人区域显示，不删节、不改写、不串人。大曾子的原话默认用作主标题 `大曾子：原话`，其人物区不再重复同句；副标题为 `M月D日博主持仓成绩榜`。当次用户明确指定标题/主角时记录为用户输入，不伪称源图原话。
- 全图不出现“股市小新”“战绩”“X人上阵”、排名编号、收益承诺。页脚可写 `@李哥复盘日记 搜集整理，仅作记录，不构成投资建议`。

核验清单存为 `YYYY-MM-DD_草原博主排名_核验记录.json`；同日重试读取它并确认来源作品没有变化，避免重复抄录和反复改数。记录作品 URL、上海发布时间、截图/原图路径及每人的字段出处。渲染器不能自己抓数据或推算缺失值。

## 默认 Image2.5 整图生成

已核验来源与全部上榜者字段后，优先使用当前平台内置的原生 Image2.5 整图路线生成一张 9:16 海报。按参考顺序逐人绑定姓名、卡片和数据；若“风格图 + 全部单人头像”超过原生工具参考图上限，先制作最少数量的临时身份参考板，每个人只出现一次并清楚标名，再与最近一期已验收海报一同提交。身份参考板只作模型输入，正式成品仍须整图生成，不能把参考板中的人物程序贴回。最近一期海报只作风格参考，不能替代人物参考或提供今日数值。精确提示词包含核验清单中的全部姓名、总数、今日盈亏、收益率、原话、主副标题、日期和页脚，不让模型补全或改写。生成工具回传版本时记录；未回传时不虚构具体子版本。生图成本以单张标准调用为界，自动重试不得重复付费。

ChatCut 仅是原生路线不可用时的备选。ChatCut 返回 `FEATURE_NOT_INCLUDED` 或套餐限制时不重复调用；原生工具可用则直接继续原生整图生成。若两条整图路线均不可用，停止并说明限制，不能擅自改走混合合成。缺少参考图输入能力的工具不得用于这类真人身份海报的正式整图。

为降低抖音将系列内容判为模板化批量低质的风险，生成前查看最近至少 3 张正式海报，并在提示词中明确当天新的视觉方案。新方案必须在“整体分区/卡片编排、主角构图/人物尺度、空间透视、主要材质、背景场景、红绿光路、标题字形处理、数据牌轮廓”中至少改变 3 项。不能把同一版式只换数字、日期、颜色、镜像或局部装饰当作新设计。准确数据、固定人物身份、全员展示和可读性仍是硬约束，视觉变化不能以删人、删字段、错字或改脸为代价。

逐人将候选图与原头像比较五官、脸型、眼镜、发型、表情和原服装；逐字核对全部数字、标点和引语。候选有脸部变化、遗漏、错字或串人时，只保留为试稿；不通过程序贴头像或叠字伪称整图生成。进一步付费修正或改走混合合成，等待用户选择。

## 可选混合模式：Image2 预生成背景池与每日独占背景

不必等待当天成绩单发布。可提前生成 2–3 张未指定海报日期的 9:16 背景候选，放在项目备用池 `/Users/D盘/CodexPro/ShiPin/capital-flow-mvp/backgrounds/blogger-reserve`。**只预生背景，不预填日期、标题、人物、数字或原话，也不制作当天成品。**每张候选必须是独立的 Image2 或更高版本原创，不能从历史成品调色、裁切、镜像或微改得到。生成后人工检查画面不含人物、人脸、姓名、文字、数字、数据牌、Logo。提示词示例：

```text
Use case: stylized-concept.
Asset: 9:16 reusable undated background candidate for a Chinese daily financial-data poster.
Scene: dark financial-tech environment with balanced red and green candlestick-inspired light, layered market textures, natural continuous backdrop.
Variation: architectural structure, perspective, main material and light path should differ clearly from recent days in at least two dimensions.
Keep the central reading areas calm enough for portraits and precise data to be composited later.
No date, people, faces, letters, Chinese characters, digits, numbers, logos, data cards, arrows, trophies, medals, crowns, podiums, flames or promises of profit.
```

候选图先保存在生成工具返回路径，运行以下命令，同时与已交付背景和备用池查重：

```bash
/Users/D盘/CodexPro/ShiPin/.venv/bin/python \
  /Users/jinru/.codex/skills/make-daily-blogger-performance-poster/scripts/check_background_uniqueness.py \
  <候选背景.png> \
  --history-dir /Users/jinru/Desktop/博主今日战绩/背景 \
  --history-dir /Users/D盘/CodexPro/ShiPin/capital-flow-mvp/backgrounds/blogger-posters \
  --history-dir /Users/D盘/CodexPro/ShiPin/capital-flow-mvp/backgrounds/blogger-reserve
```

要求 `ok=true`、人工确认主体结构明显不同，且生成工具/记录明确显示模型为 Image2 或更高，方可非覆盖地收入备用池。文件名用**生成日期**开头，如 `2026-10-30_预生成_矿物哑光_v1.png`，附同名 JSON 记录生成日期、可核验模型标识、提示词摘要、SHA-256、状态 `unused`。工具未提供模型标识时，不猜测为 Image2；候选隔离到 `capital-flow-mvp/backgrounds/blogger-unverified/`，不得入正式备用池或用于正式海报。它不是 10 月 30 日的成品或指定日期背景。

当天来源及固定九人数据核验通过后，从备用池优先取一张 `unused` 候选，重新运行上述查重（工具会跳过候选自身）；再次人工确认与近期正式海报差异明显，且背景适合当天文案长度。确认目标文件不存在，再**移动**候选图（不是复制）到桌面 `背景/YYYY-MM-DD_image2_background_vN.png`，元数据同步移到正式归档并标记 `claimed_for: YYYY-MM-DD`；这样池内不会再出现已用图。若同一天已有归档背景，直接复用它，不再领取第二张；若无合格候选，才临时生成。候选无“当天行情”属性，生成日期与使用日期可不同，但绝不可取历史已交付图。背景查重只能降低重复内容风险，不能保证抖音审核结果。

## 可选混合模式：合成与版式

使用本技能的通用渲染脚本读取日期清单、背景和固定照片，生成 1080×1920 正图与居中 1080×1440（Y=240–1680）的 3:4 预览。程序可绘制精确标题、姓名、收益数据、原话、页脚及卡片，确保同一条记录的人与数据一起布局，不用 Image2 重绘头像或数字。人物布局和主视觉可随当天收益率、原话长短及背景结构变化，不要每天只换数字；收益数据可读性高于装饰。总数/今日两行不画横线、下划线或分隔线。

通用脚本是 `scripts/render_hybrid_poster.py`。清单是人工核验后保存的 JSON 对象，至少包含：

```json
{
  "date": "2026-10-30",
  "source_date": "2026-10-30",
  "verified": true,
  "source_url": "当天真实作品 URL",
  "title": "大曾子：当天已核实原话",
  "title_source": "source",
  "hero": "dazengzi",
  "layout_variant": "auto",
  "people": [
    {
      "name": "大曾子",
      "slug": "dazengzi",
      "total": "19.5w",
      "today": "-17,138",
      "pct": "-8.08%",
      "quote": "当天已核实原话"
    }
  ]
}
```

上面仅演示字段结构，**不是 2026-10-30 的真实数据，严禁直接用于生成当天海报**。实际清单应包含固定九人中所有有当日可核实收益率者，并记录真实 `source_url` 或 `source_image`。若标题为用户当次指定，设 `title_source: "user"`；默认来源标题必须逐字等于 `大曾子：<该行quote>`。运行顺序：

```bash
/Users/D盘/CodexPro/ShiPin/.venv/bin/python \
  /Users/jinru/.codex/skills/make-daily-blogger-performance-poster/scripts/render_hybrid_poster.py \
  --manifest <当天核验记录.json> --check-only

/Users/D盘/CodexPro/ShiPin/.venv/bin/python \
  /Users/jinru/.codex/skills/make-daily-blogger-performance-poster/scripts/render_hybrid_poster.py \
  --manifest <当天核验记录.json> --background <当天已查重Image2背景.png>
```

第二步只写 `YYYY-MM-DD_草原博主排名_草稿_vN.png` 与草稿 3:4 预览，返回 `draft_requires_visual_review`，**不算正式成品**。完整验收及查重通过后才执行：

```bash
/Users/D盘/CodexPro/ShiPin/.venv/bin/python \
  /Users/jinru/.codex/skills/make-daily-blogger-performance-poster/scripts/render_hybrid_poster.py \
  --manifest <当天核验记录.json> --finalize-draft <已验收草稿.png>
```

此步把混合草稿非覆盖地晋级为日期开头的正式正图，并生成正式 3:4 预览；只有已验收的正式正图才可交付。

画布背景自然连续，保留普通视觉边距和平台控件避让，不预留顶部 10%、右侧 7%、底部 15% 的固定纯色带。主页 3:4 裁切后主标题、副标题、每位姓名、收益率、原话必须完整可读；人脸不能压住文字。禁止箭头、奖杯、奖牌、皇冠、领奖台、火焰及收益承诺视觉。准确呈现全部九人中当日有可核实收益率者，不能精选遗漏。

## 验收、查重与命名

逐行比较核验清单与正图：人物数及身份、姓名、总数、今日盈亏、收益率、正负号、英文逗号、`w`、每人原话、主标题、副标题日期、页脚全部一致；大曾子标题句不在人物区重复。检查红涨绿跌、照片未变脸/换衣、数据牌不遮脸、无“股市小新”“战绩”、无排名编号和收益暗示。正式成品必须为 1080×1920，3:4 预览关键内容完整。

完整候选海报对历史正式海报再次查重，排除同一天的草稿与版本。命令返回 `ok=true` 后仍须人工确认至少 3 项结构性视觉变化；任一检查不通过都不得晋级正式成品：

```bash
/Users/D盘/CodexPro/ShiPin/.venv/bin/python \
  /Users/jinru/.codex/skills/make-daily-blogger-performance-poster/scripts/check_background_uniqueness.py \
  <候选海报.png> \
  --history-dir /Users/jinru/Desktop/博主今日战绩 \
  --pattern '*草原博主排名*1080x1920*.png' \
  --exclude-date YYYY-MM-DD
```

正式目录：`/Users/jinru/Desktop/博主今日战绩`。命名一律日期开头：

- 正图：`YYYY-MM-DD_草原博主排名_抖音安全区_1080x1920.png`
- 同日明确重做：在扩展名前加 `_v2`、`_v3`，不得覆盖旧图。
- 预览：`YYYY-MM-DD_草原博主排名_主页3x4预览.png`
- 清单：`YYYY-MM-DD_草原博主排名_核验记录.json`
- 草稿：`YYYY-MM-DD_草原博主排名_草稿_vN.png`

自动任务需同时识别旧正式命名 `草原博主排名_YYYY-MM-DD_抖音安全区_1080x1920*.png`。已有当日验收成品不因新命名而重生；未验收的整图候选及被用户否决版本不能当作已验收正式成品。是否补交由用户当次指定渠道及本对话交付记录决定。

## 当前对话与 Hermes

正式正图通过全部验收后按顺序双重交付：先在当前对话展示正式原图和可点击本地链接，再查询当前有效 `feishu:<chat_id>`，不得猜地址，并用 Hermes 将同一正式原图作为图片附件发送到当前飞书对话。只有返回 `success=true` 可称“飞书已发送”。临时失败按全局故障流程检查并只重试一次，仍失败则保留当前对话交付、提供绝对路径和错误，不改用 Computer Use 操作飞书。用户当次明确要求“只发这里/不用传飞书”时才跳过 Hermes。完成时给一条以当日已核实事实写的抖音标题。已有当前对话交付但缺 Hermes 成功记录时只补发 Hermes，不重新生图；两处均已成功时不重复交付。无新正式成品时不贴旧图冒充完成。
