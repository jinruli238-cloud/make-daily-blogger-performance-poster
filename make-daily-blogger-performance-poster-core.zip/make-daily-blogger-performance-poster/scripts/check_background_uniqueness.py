#!/usr/bin/env python3
"""Reject an exact or near-duplicate daily blogger poster or background."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from PIL import Image


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def pixels(path: Path, mode: str, size: tuple[int, int]) -> list:
    with Image.open(path) as image:
        return list(image.convert(mode).resize(size, Image.Resampling.LANCZOS).getdata())


def dhash(path: Path) -> tuple[bool, ...]:
    gray = pixels(path, "L", (17, 16))
    return tuple(gray[y * 17 + x] > gray[y * 17 + x + 1] for y in range(16) for x in range(16))


def ahash(path: Path) -> tuple[bool, ...]:
    gray = pixels(path, "L", (16, 16))
    average = sum(gray) / len(gray)
    return tuple(value > average for value in gray)


def hamming(left: tuple[bool, ...], right: tuple[bool, ...]) -> int:
    return sum(a != b for a, b in zip(left, right))


def mean_absolute_difference(left: Path, right: Path) -> float:
    a = pixels(left, "RGB", (64, 64))
    b = pixels(right, "RGB", (64, 64))
    return sum(abs(x - y) for p, q in zip(a, b) for x, y in zip(p, q)) / (len(a) * 3)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("--history-dir", type=Path, action="append", required=True)
    parser.add_argument("--pattern", default="*.png", help="Glob pattern for historical images")
    parser.add_argument(
        "--exclude-date",
        help="Ignore historical files whose name contains this YYYY-MM-DD date (same-day drafts/versions)",
    )
    parser.add_argument("--minimum-dhash-distance", type=int, default=64)
    parser.add_argument("--minimum-ahash-distance", type=int, default=40)
    parser.add_argument("--maximum-similar-mad", type=float, default=10.0)
    args = parser.parse_args()

    candidate = args.candidate.resolve()
    if not candidate.is_file():
        parser.error(f"candidate does not exist: {candidate}")

    history = sorted({
        image.resolve()
        for folder in args.history_dir
        if folder.is_dir()
        for image in folder.rglob(args.pattern)
        if image.resolve() != candidate
        and (not args.exclude_date or args.exclude_date not in image.name)
    })
    candidate_sha = sha256(candidate)
    candidate_dhash = dhash(candidate)
    candidate_ahash = ahash(candidate)
    comparisons = []

    for previous in history:
        exact = sha256(previous) == candidate_sha
        d = hamming(candidate_dhash, dhash(previous))
        a = hamming(candidate_ahash, ahash(previous))
        mad = mean_absolute_difference(candidate, previous)
        similar_signals = (
            d < args.minimum_dhash_distance,
            a < args.minimum_ahash_distance,
            mad < args.maximum_similar_mad,
        )
        comparisons.append({
            "path": str(previous),
            "exact_sha256_match": exact,
            "dhash_distance": d,
            "ahash_distance": a,
            "mean_absolute_difference": round(mad, 2),
            "conflict": exact or sum(similar_signals) >= 2,
        })

    conflicts = [item for item in comparisons if item["conflict"]]
    comparisons.sort(key=lambda item: (item["dhash_distance"] + item["ahash_distance"], item["mean_absolute_difference"]))
    print(json.dumps({
        "ok": not conflicts,
        "candidate": str(candidate),
        "sha256": candidate_sha,
        "history_count": len(history),
        "conflicts": conflicts,
        "closest": comparisons[:5],
        "thresholds": {
            "minimum_dhash_distance": args.minimum_dhash_distance,
            "minimum_ahash_distance": args.minimum_ahash_distance,
            "maximum_similar_mad": args.maximum_similar_mad,
        },
    }, ensure_ascii=False, indent=2))
    if conflicts:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
