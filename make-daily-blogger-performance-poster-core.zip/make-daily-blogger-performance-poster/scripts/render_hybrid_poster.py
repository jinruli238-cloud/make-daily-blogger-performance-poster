#!/usr/bin/env python3
"""Render a verified daily blogger poster from an Image2 background and fixed photos.

This is intentionally content-deterministic: it never asks an image model to redraw
faces or copy numerical data. Source verification and background generation happen
before this script runs.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import shutil
from datetime import date
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps


W, H = 1080, 1920
ROOT = Path("/Users/jinru/Desktop/博主今日战绩")
SKILL = Path(__file__).resolve().parents[1]
FONT_ROOT = Path("/Users/D盘/CodexPro/ShiPin/capital-flow-mvp/yztop10-youzi-video/assets/fonts")
NAMES = {
    "dahuzi": "大胡子",
    "dazengzi": "大曾子",
    "laoxu": "老徐",
    "jiepange": "接盘哥",
    "xiaozhang": "小张吃饭用缸",
    "sundaxin": "孙大鑫",
    "wangxiaoyu": "王小雨",
    "xiaoreba": "小热巴",
    "yeren": "全能的野人",
}
GOLD = (244, 203, 118, 255)
WHITE = (247, 247, 245, 255)
MUTED = (209, 216, 219, 255)
UP = (255, 82, 75, 255)
DOWN = (48, 221, 148, 255)
FOOTER = "@李哥复盘日记 搜集整理，仅作记录，不构成投资建议"


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    path = FONT_ROOT / ("NotoSansSC-Bold.otf" if bold else "NotoSansSC-Regular.otf")
    if not path.is_file():
        raise FileNotFoundError(f"缺少中文字体：{path}")
    return ImageFont.truetype(str(path), size)


def text_width(draw: ImageDraw.ImageDraw, value: str, face: ImageFont.FreeTypeFont) -> float:
    return draw.textlength(value, font=face)


def wrap(draw: ImageDraw.ImageDraw, value: str, face: ImageFont.FreeTypeFont, width: int) -> list[str]:
    lines: list[str] = []
    for paragraph in value.split("\n"):
        line = ""
        for char in paragraph:
            if line and text_width(draw, line + char, face) > width:
                lines.append(line)
                line = char
            else:
                line += char
        lines.append(line)
    return lines


def fitted_lines(
    draw: ImageDraw.ImageDraw, value: str, width: int, max_lines: int, top_size: int, min_size: int
) -> tuple[ImageFont.FreeTypeFont, list[str]]:
    for size in range(top_size, min_size - 1, -1):
        face = font(size, bold=False)
        lines = wrap(draw, value, face, width)
        if len(lines) <= max_lines:
            return face, lines
    raise ValueError(f"文字过长，无法完整排版：{value}")


def signed(value: str, suffix: str = "") -> str:
    if value == "—":
        return value
    if "万" in value or "W" in value:
        raise ValueError(f"单位必须用小写 w：{value}")
    numeric = float(value.replace(",", "").removesuffix(suffix).removesuffix("w"))
    if numeric > 0 and not value.startswith("+"):
        return "+" + value
    if numeric < 0 and not value.startswith("-"):
        raise ValueError(f"负数缺少负号：{value}")
    return value


def validate_manifest(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("核验记录必须是 JSON 对象")
    day = payload.get("date")
    if not isinstance(day, str):
        raise ValueError("缺少 date")
    try:
        date.fromisoformat(day)
    except ValueError as exc:
        raise ValueError("date 必须为 YYYY-MM-DD") from exc
    if payload.get("source_date") != day:
        raise ValueError("source_date 必须与 date 相同，不能用旧日数据")
    if payload.get("verified") is not True:
        raise ValueError("verified 必须为 true；请先人工核验来源")
    if not (payload.get("source_url") or payload.get("source_image")):
        raise ValueError("必须提供 source_url 或 source_image 作为当日来源记录")
    title = payload.get("title")
    if not isinstance(title, str) or not title.strip():
        raise ValueError("缺少非空 title")
    if payload.get("title_source", "source") not in {"source", "user"}:
        raise ValueError("title_source 只能是 source 或 user")
    rows = payload.get("people")
    if not isinstance(rows, list) or not 1 <= len(rows) <= len(NAMES):
        raise ValueError("people 必须包含 1–9 名有当日成绩的人")
    seen: set[str] = set()
    normalized = []
    for item in rows:
        if not isinstance(item, dict):
            raise ValueError("people 中每项必须是对象")
        slug = item.get("slug")
        if slug not in NAMES or slug in seen:
            raise ValueError(f"头像 slug 未知或重复：{slug}")
        seen.add(slug)
        if item.get("name") != NAMES[slug]:
            raise ValueError(f"姓名与头像 slug 不匹配：{item.get('name')} / {slug}")
        total, today, pct, quote = (item.get(k) for k in ("total", "today", "pct", "quote"))
        if not all(isinstance(x, str) and x.strip() for x in (total, today, pct, quote)):
            raise ValueError(f"{item['name']} 缺少总数、今日、收益率或原话")
        if "万" in total or "W" in total:
            raise ValueError(f"{item['name']} 的总数单位必须用小写 w")
        if total != "—" and not re.fullmatch(r"[0-9][0-9,.]*w?", total):
            raise ValueError(f"{item['name']} 的总数格式错误：{total}")
        if today != "—" and not re.fullmatch(r"[+-]?[0-9][0-9,.]*w?", today):
            raise ValueError(f"{item['name']} 的今日格式错误：{today}")
        if not re.fullmatch(r"[+-]?[0-9]+(?:\.[0-9]+)?%", pct):
            raise ValueError(f"{item['name']} 的收益率格式错误：{pct}")
        today = signed(today)
        pct = signed(pct, "%")
        normalized.append({"name": item["name"], "slug": slug, "total": total, "today": today, "pct": pct, "quote": quote})
    visible = [title, FOOTER] + [p["name"] + p["quote"] for p in normalized]
    if any(word in part for part in visible for word in ("股市小新", "战绩")):
        raise ValueError("成品可见文字不得出现“股市小新”或“战绩”")
    dazengzi = next((p for p in normalized if p["slug"] == "dazengzi"), None)
    if payload.get("title_source", "source") == "source":
        if not dazengzi or title != f"大曾子：{dazengzi['quote']}":
            raise ValueError("来源标题必须逐字等于大曾子当日原话；用户指定标题请设 title_source=user")
    normalized.sort(key=lambda row: float(row["pct"].removesuffix("%")), reverse=True)
    hero = payload.get("hero") or normalized[0]["slug"]
    if hero not in {row["slug"] for row in normalized}:
        raise ValueError("hero 必须是当天有成绩的人")
    return {**payload, "people": normalized, "hero": hero}


def portrait_path(slug: str) -> Path:
    if slug == "yeren":
        primary = ROOT / "头像/yeren.png"
    else:
        primary = ROOT / "头像/原服装透明抠图" / f"{slug}.png"
    backup = SKILL / "assets/portraits-original-outfit" / f"{slug}.png"
    for candidate in (primary, backup):
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(f"找不到固定头像：{slug}")


def paste_portrait(base: Image.Image, slug: str, box: tuple[int, int, int, int]) -> None:
    source = Image.open(portrait_path(slug)).convert("RGBA")
    x, y, w, h = box
    alpha = source.getchannel("A")
    if alpha.getextrema()[0] < 255:
        bounds = alpha.getbbox()
        if bounds:
            source = source.crop(bounds)
        # Keep the original pixels/identity, but frame the head and upper outfit
        # instead of shrinking a full-length cutout into a small card.
        source = source.crop((0, 0, source.width, round(source.height * 0.82)))
        source = ImageOps.fit(source, (w, h), Image.Resampling.LANCZOS, centering=(0.5, 0.18))
        base.alpha_composite(source, (x, y))
        return
    # 野人原图有不透明房间背景；保留为照片窗口，不能伪装透明抠图。
    source = ImageOps.fit(source, (w, h), Image.Resampling.LANCZOS, centering=(0.5, 0.2))
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, w - 1, h - 1), radius=18, fill=255)
    source.putalpha(mask)
    base.alpha_composite(source, (x, y))


def panel(base: Image.Image, rect: tuple[int, int, int, int], pct: str) -> None:
    overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    accent = DOWN if pct.startswith("-") else (UP if pct.startswith("+") else GOLD)
    draw.rounded_rectangle(rect, radius=24, fill=(2, 8, 14, 218), outline=(173, 142, 84, 235), width=2)
    x1, y1, x2, _ = rect
    draw.rounded_rectangle((x1 + 18, y1 + 7, x2 - 18, y1 + 12), radius=2, fill=accent)
    base.alpha_composite(overlay)


def card(base: Image.Image, person: dict, rect: tuple[int, int, int, int], hero: bool, photo_right: bool, show_quote: bool) -> None:
    x, y, w, h = rect
    panel(base, (x, y, x + w, y + h), person["pct"])
    draw = ImageDraw.Draw(base)
    photo_w = 220 if hero else 126
    photo_h = h - 30
    photo_x = x + w - photo_w - 17 if photo_right else x + 17
    paste_portrait(base, person["slug"], (photo_x, y + 20, photo_w, photo_h))
    text_x = x + 25 if photo_right else photo_x + photo_w + (24 if hero else 14)
    text_w = w - photo_w - (70 if hero else 62)
    max_name_size = 38 if hero else 28
    face, lines = fitted_lines(draw, person["name"], text_w, 1, max_name_size, 22)
    draw.text((text_x, y + (20 if hero else 17)), lines[0], font=face, fill=GOLD, stroke_width=1, stroke_fill=(0, 0, 0))
    detail_font = None
    for size in range(23 if hero else 19, 13, -1):
        candidate = font(size)
        if all(text_width(draw, line, candidate) <= text_w for line in
               (f"总数 {person['total']}", f"今日 {person['today']}")):
            detail_font = candidate
            break
    if detail_font is None:
        raise ValueError(f"数据行放不下：{person['name']}")
    draw.text((text_x, y + (65 if hero else 52)), f"总数 {person['total']}", font=detail_font, fill=WHITE)
    today_color = DOWN if person["today"].startswith("-") else (UP if person["today"].startswith("+") else WHITE)
    draw.text((text_x, y + (92 if hero else 77)), f"今日 {person['today']}", font=detail_font, fill=today_color)
    pct_font = font(52 if hero else 38, bold=True)
    pct_color = DOWN if person["pct"].startswith("-") else (UP if person["pct"].startswith("+") else WHITE)
    draw.text((text_x, y + (119 if hero else 103)), person["pct"], font=pct_font, fill=pct_color, stroke_width=2, stroke_fill=(0, 0, 0))
    if show_quote:
        quote = person["quote"]
        quote_top = 179 if hero else 153
        available = h - quote_top - 9
        for size in range(24 if hero else 21, 14, -1):
            quote_font = font(size)
            quote_lines = wrap(draw, quote, quote_font, text_w)
            line_h = size + 5
            if len(quote_lines) * line_h <= available:
                for index, line in enumerate(quote_lines):
                    draw.text((text_x, y + quote_top + index * line_h), line, font=quote_font, fill=MUTED)
                break
        else:
            raise ValueError(f"原话过长，不能完整显示：{person['name']}：{quote}")


def next_final_paths(folder: Path, day: str) -> tuple[Path, Path]:
    old = list(folder.glob(f"草原博主排名_{day}_抖音安全区_1080x1920*.png"))
    new = list(folder.glob(f"{day}_草原博主排名_抖音安全区_1080x1920*.png"))
    existing = old + new
    versions = [1]
    for path in existing:
        match = re.search(r"_v(\d+)\.png$", path.name)
        versions.append(int(match.group(1)) if match else 1)
    version = max(versions) + 1 if existing else 1
    suffix = "" if version == 1 else f"_v{version}"
    return (
        folder / f"{day}_草原博主排名_抖音安全区_1080x1920{suffix}.png",
        folder / f"{day}_草原博主排名_主页3x4预览{suffix}.png",
    )


def next_draft_paths(folder: Path, day: str) -> tuple[Path, Path]:
    existing = list(folder.glob(f"{day}_草原博主排名_草稿_v*.png"))
    versions = []
    for path in existing:
        match = re.fullmatch(rf"{re.escape(day)}_草原博主排名_草稿_v(\d+)\.png", path.name)
        if match:
            versions.append(int(match.group(1)))
    version = max(versions, default=0) + 1
    return (
        folder / f"{day}_草原博主排名_草稿_v{version}.png",
        folder / f"{day}_草原博主排名_草稿_主页3x4预览_v{version}.png",
    )


def render(payload: dict, background: Path, output_dir: Path) -> dict:
    if not background.is_file():
        raise FileNotFoundError(f"Image2 背景不存在：{background}")
    people = payload["people"]
    for person in people:
        portrait_path(person["slug"])
    base = ImageOps.fit(Image.open(background).convert("RGBA"), (W, H), Image.Resampling.LANCZOS)
    draw = ImageDraw.Draw(base)
    title_font, title_lines = fitted_lines(draw, payload["title"], 940, 2, 66, 37)
    title_y = 258
    title_line_h = title_font.size + 12
    for index, line in enumerate(title_lines):
        draw.text((W // 2, title_y + index * title_line_h), line, font=title_font, fill=GOLD, anchor="ma", stroke_width=4, stroke_fill=(0, 0, 0))
    month, day = (int(x) for x in payload["date"].split("-")[1:])
    subtitle = f"{month}月{day}日博主持仓成绩榜"
    draw.text((W // 2, 409), subtitle, font=font(31, bold=True), fill=WHITE, anchor="ma", stroke_width=2, stroke_fill=(0, 0, 0))
    hero = next(row for row in people if row["slug"] == payload["hero"])
    remainder = [row for row in people if row["slug"] != payload["hero"]]
    hero_y, hero_h = 476, 245
    layout_right = payload.get("layout_variant", "auto") == "right" or (
        payload.get("layout_variant", "auto") == "auto" and int(payload["date"][-2:]) % 2 == 1
    )
    card(base, hero, (58, hero_y, 964, hero_h), True, layout_right, payload["title"] != f"{hero['name']}：{hero['quote']}")
    rows = math.ceil(len(remainder) / 2)
    if rows:
        start_y, end_y, gap_y = 736, 1662, 13
        row_h = min(266, (end_y - start_y - gap_y * (rows - 1)) // rows)
        col_w, gap_x = 474, 16
        for index, person in enumerate(remainder):
            col, row = index % 2, index // 2
            x = 58 + col * (col_w + gap_x)
            y = start_y + row * (row_h + gap_y)
            photo_right = layout_right if col == 0 else not layout_right
            card(base, person, (x, y, col_w, row_h), False, photo_right, payload["title"] != f"{person['name']}：{person['quote']}")
    draw = ImageDraw.Draw(base)
    draw.text((W // 2, 1773), FOOTER, font=font(22), fill=GOLD, anchor="ma", stroke_width=2, stroke_fill=(0, 0, 0))
    output_dir.mkdir(parents=True, exist_ok=True)
    result, preview = next_draft_paths(output_dir, payload["date"])
    for path, image in ((result, base.convert("RGB")), (preview, base.crop((0, 240, 1080, 1680)).convert("RGB"))):
        with path.open("xb") as handle:
            image.save(handle, format="PNG", optimize=True)
    return {"status": "draft_requires_visual_review", "date": payload["date"], "rows": len(people), "draft": str(result), "preview": str(preview), "background": str(background)}


def finalize(payload: dict, draft: Path, output_dir: Path) -> dict:
    """Promote only an explicitly approved draft; never overwrite a prior final."""
    pattern = rf"{re.escape(payload['date'])}_草原博主排名_草稿_v\d+\.png"
    if not draft.is_file() or not re.fullmatch(pattern, draft.name):
        raise ValueError("只允许将本日期、日期前缀的草稿 PNG 转为正式成品")
    with Image.open(draft) as source:
        if source.size != (W, H):
            raise ValueError(f"草稿尺寸不是 {W}×{H}：{source.size}")
        preview_image = source.crop((0, 240, 1080, 1680)).convert("RGB")
    output_dir.mkdir(parents=True, exist_ok=True)
    final_path, preview_path = next_final_paths(output_dir, payload["date"])
    with draft.open("rb") as src, final_path.open("xb") as dst:
        shutil.copyfileobj(src, dst)
    with preview_path.open("xb") as handle:
        preview_image.save(handle, format="PNG", optimize=True)
    return {"status": "finalized_after_visual_approval", "date": payload["date"], "rows": len(payload["people"]), "poster": str(final_path), "preview": str(preview_path), "from_draft": str(draft)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True, help="人工核验后的当天 JSON 数据")
    parser.add_argument("--background", type=Path, help="当天独占、已查重的 Image2 无字无人背景（可来自预生成备用池）")
    parser.add_argument("--output-dir", type=Path, default=ROOT)
    parser.add_argument("--check-only", action="store_true", help="仅校验当天数据，不写图")
    parser.add_argument("--finalize-draft", type=Path, help="人工逐项验收后，显式把本日期草稿晋级为正式成品")
    args = parser.parse_args()
    payload = validate_manifest(json.loads(args.manifest.read_text(encoding="utf-8")))
    if args.check_only:
        print(json.dumps({"status": "validated", "date": payload["date"], "rows": len(payload["people"]), "hero": payload["hero"]}, ensure_ascii=False))
        return
    if args.finalize_draft is not None:
        if args.background is not None:
            parser.error("--finalize-draft 不需要 --background")
        print(json.dumps(finalize(payload, args.finalize_draft, args.output_dir), ensure_ascii=False))
        return
    if args.background is None:
        parser.error("生成草稿必须提供 --background")
    print(json.dumps(render(payload, args.background, args.output_dir), ensure_ascii=False))


if __name__ == "__main__":
    main()
