#!/usr/bin/env node

import { createRequire } from 'node:module';
import { existsSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

const [inputPath, outputPath] = process.argv.slice(2);

if (!inputPath || !outputPath) {
  console.error('Usage: compose_safe_canvas.mjs <image2-input> <output-png>');
  process.exit(2);
}

const moduleRoots = [
  process.env.CODEX_WORKSPACE_NODE_MODULES,
  join(homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'),
].filter(Boolean);

let sharp;
for (const root of moduleRoots) {
  const packageJson = join(root, 'sharp', 'package.json');
  if (!existsSync(packageJson)) continue;
  const require = createRequire(packageJson);
  sharp = require('sharp');
  break;
}

if (!sharp) {
  console.error('Could not find sharp. Set CODEX_WORKSPACE_NODE_MODULES to the Node.js packages path returned by load_workspace_dependencies.');
  process.exit(3);
}

const input = sharp(inputPath);
const metadata = await input.metadata();
if (!metadata.width || !metadata.height) {
  throw new Error('Input image dimensions are unavailable.');
}

// Preserve the complete Image2 headline and footer without changing aspect
// ratio. Align the poster's right and bottom edges to the user-defined 7% and
// 15% blank zones while keeping it inside the 3:4 profile-grid crop.
const cropTop = 0;
const cropBottom = 0;
const cropHeight = metadata.height - cropTop - cropBottom;

const rightMargin = 76;
const bottomMargin = 288;
const maxCoreWidth = 1080 - rightMargin - 76;
const maxCoreHeight = 1920 - bottomMargin - 240;
const scale = Math.min(maxCoreWidth / metadata.width, maxCoreHeight / cropHeight);
const coreWidth = Math.round(metadata.width * scale);
const coreHeight = Math.round(cropHeight * scale);
const coreLeft = 1080 - rightMargin - coreWidth;
const coreTop = 1920 - bottomMargin - coreHeight;

const core = await input
  .extract({ left: 0, top: cropTop, width: metadata.width, height: cropHeight })
  .resize(coreWidth, coreHeight, { fit: 'fill' })
  .png()
  .toBuffer();

const background = Buffer.from(`
<svg width="1080" height="1920" viewBox="0 0 1080 1920" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#02070c"/>
      <stop offset="0.52" stop-color="#071016"/>
      <stop offset="1" stop-color="#020509"/>
    </linearGradient>
    <pattern id="grid" width="120" height="120" patternUnits="userSpaceOnUse">
      <path d="M120 0H0V120" fill="none" stroke="#b88943" stroke-opacity="0.16" stroke-width="1"/>
    </pattern>
  </defs>
  <rect width="1080" height="1920" fill="url(#bg)"/>
  <rect width="1080" height="1920" fill="url(#grid)"/>
  <g opacity="0.35" stroke-width="2">
    <path d="M0 1640 C200 1570 360 1700 540 1660 S860 1600 1080 1630" fill="none" stroke="#b8792c"/>
    <path d="M0 310 C220 250 390 380 570 330 S860 250 1080 290" fill="none" stroke="#1f8d64"/>
  </g>
  <g opacity="0.35">
    <path d="M20 90v70 M12 115h16" stroke="#e84134" stroke-width="3"/>
    <path d="M80 125v80 M72 150h16" stroke="#25a76f" stroke-width="3"/>
    <path d="M1010 85v90 M1002 120h16" stroke="#25a76f" stroke-width="3"/>
    <path d="M1060 120v75 M1052 145h16" stroke="#e84134" stroke-width="3"/>
    <path d="M20 1700v80 M12 1725h16" stroke="#e84134" stroke-width="3"/>
    <path d="M80 1740v95 M72 1775h16" stroke="#25a76f" stroke-width="3"/>
    <path d="M1010 1695v90 M1002 1730h16" stroke="#25a76f" stroke-width="3"/>
    <path d="M1060 1730v85 M1052 1760h16" stroke="#e84134" stroke-width="3"/>
  </g>
</svg>`);

await sharp(background)
  .composite([{ input: core, left: coreLeft, top: coreTop }])
  .png()
  .toFile(outputPath);

console.log(JSON.stringify({
  output: outputPath,
  width: 1080,
  height: 1920,
  safe_core: { x1: coreLeft, y1: coreTop, x2: coreLeft + coreWidth, y2: coreTop + coreHeight },
  reserved_blank: { right: rightMargin, bottom: bottomMargin },
}));
